import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { DetailsComponent } from './details/details.component';
import { LoginComponent } from './login/login.component';
import { MasterComponent } from './master/master.component';
import { AddbatchComponent } from './addbatch/addbatch.component';
import { AdmissionComponent } from './admission/admission.component';


const routes: Routes = [
  {"path":"masterpath/Batch_List",component:MasterComponent},
  {"path":"loginpath",component:LoginComponent},
   { "path":"addbatch",component:AddbatchComponent },
{ "path" : "admissionpath",component:AdmissionComponent}
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }