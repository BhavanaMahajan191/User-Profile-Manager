import { Component, OnInit } from '@angular/core';
import { BatchList } from '../pojo/BatchList';
import { DataService, Options } from '../service/data.service';
// import { BatchMaster } from '../pojo/BatchMaster';
import {ViewChild} from '@angular/core';
import {MatPaginator} from '@angular/material/paginator';
import {MatTableDataSource} from '@angular/material/table';
import { Router } from '@angular/router';

@Component({
  selector: 'app-master',
  templateUrl: './master.component.html',
  styleUrls: ['./master.component.css']
})
export class MasterComponent implements OnInit{


  batchs:any=[ ];
  batchObj:BatchList=new BatchList ();
  option:Options=new Options();
  flag:string="";

  ELEMENT_DATA: BatchList[]=new Array();
displayedColumns: string[] = ['batch_id', 'course_name', 'starting_date', 'batch_time','faculty_name'];
dataSource = new MatTableDataSource<BatchList>(this.ELEMENT_DATA);

constructor(private dataService:DataService,private router:Router){}

@ViewChild(MatPaginator, {static: true}) paginator: any;


  ngOnInit(): void {
    this.fillList();
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
      }
  fillList()
  {
    this.dataService.getData("BatchMaster/Batch_List",this.option).subscribe(data=>{this.batchs=data;alert(JSON.stringify(this.batchs));});
    this.clearData();

    this.dataService.getData("BatchMaster/Batch_List",this.option).subscribe(data=>{this.ELEMENT_DATA=data; /*alert(JSON.stringify(this.ELEMENT_DATA));*/ this.dataSource = new MatTableDataSource<BatchList>(this.ELEMENT_DATA); this.dataSource.paginator = this.paginator;}); 
    this.clearData();
  }
  clearData(){
    this.batchObj.batch_id=0;
    this.batchObj.course_name=" ";
    this.batchObj.starting_date=" ";
    this.batchObj.batch_time="";
    this.batchObj.faculty_name=" ";
  }

  save(){
    if(this.flag=="Add")
    this.dataService.insertData("BatchMaster/Batch_List",this.batchObj,this.option).subscribe(data=>{this.fillList();});
    else
    this.dataService.updateData("BatchMaster/Batch_List",this.batchObj,this.option).subscribe(data=>{this.fillList();});

  }
  edit(){
    this.dataService.insertData("BatchMaster/Batch_List",this.batchObj,this.option).subscribe(data=>{this.fillList();});

  }
  submit(){
    this.router.navigateByUrl('/addbatch');
    this.dataService.insertData("BatchMaster/Batch_List",this.batchObj,this.option).subscribe(data=>{this.fillList();});

  }
}
