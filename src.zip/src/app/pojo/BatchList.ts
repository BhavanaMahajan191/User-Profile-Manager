export class BatchList{

    batch_id:number=0;
    course_name:string="";
    starting_date:string=" ";
    batch_time:string=" ";
    faculty_name:string=" ";
    // update:string="";
    // delete:string="";
    // img:string="";
}