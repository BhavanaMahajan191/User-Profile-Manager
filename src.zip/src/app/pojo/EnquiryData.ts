export class enquiry{
    enquiry_no:number=0;
    student_name:string="";
    select:string="";
}