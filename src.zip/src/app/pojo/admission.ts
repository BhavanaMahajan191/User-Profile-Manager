  
  export class Admission{
  admission_srno:number=0;
    admission_id:number=0;
    batch_add_id:number=0;
    total_course_fees:number=0;
    discount_amount:number=0;
    balance :number=0;
    organizationid :number=0;
  } 